# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'fd234955848ab81f5fcbaf572e0a95d3d495199953caa9f3fba9e461294ebfd4dff72a5510128405de491cba7c8515589e7461ed408f4a99d401267309e1028a'
